from django.shortcuts import render, redirect  # render para exibir templates, redirect para redirecionar páginas
from django.contrib.auth import authenticate, login  # authenticate verifica as credenciais, login faz login do usuário
from django.contrib.auth.models import User  # Modelo de usuário padrão do Django
from django.contrib import messages  # Permite enviar mensagens (ex: erro ou sucesso) para o template

def login_usuario(request):
    if request.method == "POST":  # Verifica se o formulário foi enviado (método POST)
        username = request.POST.get('username')  # Pega o nome de usuário digitado no formulário
        senha = request.POST.get('senha')  # Pega a senha digitada no formulário
        usuario = authenticate(request, username=username, password=senha)  # Verifica se as credenciais são válidas

        if usuario is not None:  # Se encontrou um usuário com essas credenciais
            login(request, usuario)  # Faz login do usuário
            return redirect('produtos:home')  # Redireciona para a home da loja (ou outra página definida)
        else:
            messages.error(request, "Usuário ou senha inválidos")  # Envia mensagem de erro para o template

    return render(request, 'usuarios/login.html')  # Exibe o formulário de login (em caso de GET ou erro)

def cadastro_usuario(request):
    if request.method == "POST":  # Se o formulário de cadastro foi enviado
        username = request.POST.get('username')  # Pega o nome de usuário do formulário
        email = request.POST.get('email')  # Pega o e-mail do formulário
        senha = request.POST.get('senha')  # Pega a senha do formulário

        if User.objects.filter(username=username).exists():  # Verifica se já existe um usuário com esse nome
            messages.error(request, "Nome de usuário já existe")  # Exibe erro se o nome estiver em uso
        else:
            user = User.objects.create_user(username=username, email=email, password=senha)  # Cria novo usuário
            login(request, user)  # Faz login automático após cadastro
            return redirect('produtos:home')  # Redireciona para a home da loja

    return render(request, 'usuarios/cadastro.html')  # Exibe o formulário de cadastro (em caso de GET ou erro)
