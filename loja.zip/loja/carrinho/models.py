# carrinho/models.py

from django.db import models
from produtos.models import ProdutosModel

class ItemCarrinho(models.Model):
    produto = models.ForeignKey(ProdutosModel, on_delete=models.CASCADE)
    quantidade = models.PositiveIntegerField(default=1)

    @property
    def subtotal(self):
        return self.produto.preco * self.quantidade

    def __str__(self):
        return f'{self.quantidade}x {self.produto.nome}'
