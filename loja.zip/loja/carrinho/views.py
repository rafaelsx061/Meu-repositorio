from django.shortcuts import render, redirect, get_object_or_404  # Importa funções úteis para views
from produtos.models import ProdutosModel  # Importa o modelo de produto
from .models import ItemCarrinho  # Importa o modelo de item do carrinho

def adicionar_ao_carrinho(request, produto_id):
    produto = get_object_or_404(ProdutosModel, id=produto_id)  # Busca o produto pelo ID ou retorna 404 se não existir

    item, criado = ItemCarrinho.objects.get_or_create(produto=produto)  # Tenta buscar o item no carrinho, ou cria um novo
    if not criado:  # Se o item já existia no carrinho
        item.quantidade += 1  # Aumenta a quantidade
    item.save()  # Salva o item no banco de dados

    return redirect('carrinho:ver_carrinho')  # Redireciona para a visualização do carrinho

def ver_carrinho(request):
    itens = ItemCarrinho.objects.all()  # Busca todos os itens do carrinho
    total = sum(item.subtotal for item in itens)  # Calcula o total somando os subtotais dos itens
    return render(request, 'carrinho/carrinho.html', {'itens': itens, 'total': total})  
    # Renderiza o template do carrinho e envia os itens e o total como contexto

def remover_do_carrinho(request, item_id):
    item = ItemCarrinho.objects.filter(id=item_id).first()  # Busca o item pelo ID (retorna None se não encontrar)
    if item:
        item.delete()  # Remove o item do carrinho
    # Sempre redireciona para o carrinho, mesmo se o item não existir
    return redirect('carrinho:ver_carrinho')  # Redireciona de volta para a página do carrinho
