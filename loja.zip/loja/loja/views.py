# views são funções Python que recebem a requisição do navegador e devolvem uma resposta. 
# Define o que acontece quando uma URL específica é acessada.

from django.http import HttpResponse  # Importa a classe HttpResponse para retornar texto/html diretamente como resposta
from django.shortcuts import render   # Importa o método render para retornar templates HTML renderizados

def loja_view(request):
    return HttpResponse("Essa é a minha loja!")  
    # Quando o usuário acessar a URL associada a essa view, verá a mensagem "Essa é a minha loja!" no navegador.

def index_view(request):
    return HttpResponse("<h1>Bem vindo!</h1>")  
    # Exibe a mensagem "Bem vindo!" com título HTML <h1> diretamente na resposta.

def home(request):
    return render(request, 'membros/home.html')  
    # Retorna e renderiza o template 'home.html' que está na pasta 'membros'.
    # Essa view geralmente é usada para páginas com layout HTML completo, não só texto puro.
