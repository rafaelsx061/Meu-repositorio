#URLS associa a URL à função certa do views.py.

from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static

def home_view(request):
    # Redireciona a raiz para a página principal da app produtos
    return redirect('produtos:home')

urlpatterns = [ #rota, view responsavel, nome de referencia
    path('admin/', admin.site.urls),
    path('', home_view),
    path('produtos/', include('produtos.urls')),
    path('carrinho/', include('carrinho.urls', namespace='carrinho')),
    path('usuarios/', include('usuarios.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
