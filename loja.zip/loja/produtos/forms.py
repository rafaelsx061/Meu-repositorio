from django import forms
from .models import ProdutosModel

class ProdutosForm(forms.ModelForm):
    class Meta:
        model = ProdutosModel
        fields = ['nome', 'preco', 'imagem', 'concluido'] #campos que vão ser mostrado no formulario