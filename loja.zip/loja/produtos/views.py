from django.shortcuts import render, redirect, get_object_or_404
from .forms import ProdutosForm
from .models import ProdutosModel
# render: renderiza HTML
# redirect: redireciona para outra página
# get_object_or_404: busca um objeto ou retorna erro 404 se não existir

def home(request):   # Exibe a página inicial com links, imagem ou navegação
    return render(request, 'produtos/home.html') 

def produtos(request): # Lista todos os produtos
    produtos = ProdutosModel.objects.all()
    return render(request, 'produtos/produtos.html', {'produtos': produtos})

def produtos_adicionar(request):
    if request.method == "POST":  # Se o formulário foi enviado (POST), preenche com os dados
        formulario = ProdutosForm(request.POST, request.FILES)  # Se o formulário foi enviado (POST), preenche com os dados
        if formulario.is_valid():
            formulario.save() # Salva as alterações no banco
            return redirect("produtos:produtos") # Redireciona para a lista de produtos
    else: 
        formulario = ProdutosForm()  # Se for apenas para exibir o formulário (GET), cria um formulário vazio
    return render(request, 'produtos/adicionar_produtos.html', {'formulario': formulario})


def produtos_remover(request, id):
    try:
        produto = ProdutosModel.objects.get(id=id)
        produto.delete()
    except ProdutosModel.DoesNotExist:
        pass
    return redirect("produtos:produtos") # Redireciona para a lista

def produtos_editar(request, id):
    produto = get_object_or_404(ProdutosModel, pk=id)
    if request.method == 'POST':  # Se o formulário foi enviado (POST), preenche com os dados
        form = ProdutosForm(request.POST, instance=produto) # Se o formulário foi enviado, carrega os dados com a instância existente
        if form.is_valid():
            form.save() # Salva as alterações no banco
            return redirect('produtos:produtos') 
    else:
        form = ProdutosForm(instance=produto)
    return render(request, 'produtos/editar_produtos.html', {'form': form}) # Renderiza a página de edição com o formulário preenchido
