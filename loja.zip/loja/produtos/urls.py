from django.urls import path
from . import views
from django.conf import settings   # <== Importar settings
from django.conf.urls.static import static

app_name = "produtos"

urlpatterns = [ #rota, view responsavel, nome de referencia
    path("", views.home, name="home"),  # Página inicial, chama a função home() da views.py
    path("produtos/", views.produtos, name="produtos"),  # Lista todos os produtos
    path("adicionar/", views.produtos_adicionar, name="adicionar"),  # Adiciona um novo produto
    path("editar/<int:id>/", views.produtos_editar, name="editar"),  # Edita um produto específico (passando o ID)
    path("remover/<int:id>/", views.produtos_remover, name="remover"),  # Remove um produto específico
]

if settings.DEBUG: # Se o DEBUG estiver ativado, adiciona suporte para arquivos de mídia (como imagens)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
